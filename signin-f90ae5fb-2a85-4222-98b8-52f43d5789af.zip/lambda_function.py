

import mysql.connector as my_sql
import json
def lambda_handler(event,context):
    print(event)
    message_body = event
    print(message_body)
    host  = 'usercredentials.c6opgukzdxdw.us-east-1.rds.amazonaws.com'
    database = 'userCredentials'
    user = 'aishwarya'
    password = 'aishwarya'

    queryemail=event["email"]
    querypassword=event["password"]
    conn_object = my_sql.connect(host = host, database = database, user = user, password = password)

    print(conn_object)

    #insert_query = "insert into userDetails values('trs389@nyu.edu','tejas','VERIFIED','ACTIVE',true,true,true)"


    cursor = conn_object.cursor()

    #cursor.execute(insert_query)

    cursor.execute("select * from userDetails where emailId=\'"+queryemail+ "\'")
    result=cursor.fetchall()
    print("Result", result)
    email = ""
    ver = ""
    status = ""
    page1 = ""
    page2 = ""
    page3 = ""
    foundflag = 403
    if(len(result)==1):
        result1 = list(result[0])
        if(querypassword == result1[1]):
            foundflag=200
            email=result1[0]
            ver=result1[2]
            status=result1[3]
            page1=result1[4]
            page2 = result1[5]
            page3 = result1[6]
        print('Result Dict', result1)

    cursor.close()
    conn_object.close()
    val={
        'statusCode': foundflag,
        'email': email,
        'ver': ver,
        'status': status,
        'page1': page1,
        'page2': page2,
        'page3': page3
    }
    print(val)
    
    print("Inside Lambda")
    return json.dumps(val)
    '''  var={
            'statusCode': 500,
            'body': "change done"
    }
    print(var)'''




#if __name__ == "__main__":
#   event = {"email":"tejass64@gmail.com","password":"Aishwarya1234"}
#   result = lambda_handler(event=event,context=None)
#   print(result)